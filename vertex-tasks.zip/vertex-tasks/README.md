# Vertex-level tasks

Experiments of section 4.3

### Evaluation

Evaluating model MSE with validation

```
cd evaluation
./run.sh <device>
```

### Timing

Measuring training and infere times

```
cd timing
./run.sh <device>
```


